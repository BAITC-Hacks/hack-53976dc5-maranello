import test from "node:test";
import assert from "node:assert/strict";
import { groundSuggestion, suggestBrief } from "./assistant.ts";
import { mergeAssistantDraft } from "./merge-assistant.ts";
import { taskPayloadSchema, sameTaskPayload } from "./task-payload.ts";
import { readDraftRecovery } from "./draft-recovery.ts";
import { evaluateTaskQuality } from "./quality.ts";

test("ИИ: выдуманные цитаты не заполняют поля, слова бизнеса сохраняются", () => {
  const draft = taskPayloadSchema.parse({ title: "Моя исходная задача" });
  const result = groundSuggestion({ task: { ...draft, title: "Чужое название", problem: "Менеджеры теряют заявки в таблицах", timeline: "За три недели" }, evidence: [{ field: "problem", quote: "Заявки теряются в таблицах." }, { field: "timeline", quote: "Нужно за три недели." }], questions: [], note: "Предложение." }, "Заявки теряются в таблицах.", draft);
  assert.equal(result.task.timeline, "");
  assert.equal(result.task.title, draft.title);
  assert.equal(result.task.problem, "Заявки теряются в таблицах.");
  assert.equal(result.evidence.length, 1);
});
test("настоящая тематическая цитата не пропускает выдуманную интеграцию", () => {
  const draft = taskPayloadSchema.parse({});
  const quote = "Хотим видеть ответственных и сроки в одной панели.";
  const result = groundSuggestion({ task: { ...draft, deliverables: "Панель с интеграцией в реальном времени и импортом из CRM." }, evidence: [{ field: "deliverables", quote }], questions: [], note: "Предложение" }, quote, draft);
  assert.equal(result.task.deliverables, quote);
  assert.ok(!result.task.deliverables.includes("CRM"));
});
test("ИИ применяет только выбранные пустые поля", () => {
  const current = taskPayloadSchema.parse({ title: "Своя задача" });
  const suggested = taskPayloadSchema.parse({ title: "Название от ИИ", problem: "Проблема", timeline: "Неделя", skills: ["Дизайн"] });
  const result = mergeAssistantDraft(current, suggested, ["title", "problem"]);
  assert.equal(result.title, current.title);
  assert.equal(result.problem, "Проблема");
  assert.equal(result.timeline, "");
  assert.deepEqual(result.skills, []);
});
test("повтор сохранения сравнивает содержимое, игнорируя метаданные", () => {
  const draft = taskPayloadSchema.parse({ title: "Первая версия" });
  assert.equal(sameTaskPayload(draft, { ...draft, updatedAt: 123 }), true);
  assert.equal(sameTaskPayload(draft, { ...draft, title: "Новая версия" }), false);
});
test("восстановление принимает только валидную свежую копию", () => {
  const now = Date.now();
  const copy = { version: 1, id: crypto.randomUUID(), form: taskPayloadSchema.parse({ title: "Тестовый черновик" }), description: "Исходные слова бизнеса", savedAt: now, baseUpdatedAt: null };
  assert.deepEqual(readDraftRecovery(JSON.stringify(copy), now), copy);
  assert.deepEqual(readDraftRecovery(JSON.stringify({ ...copy, form: { ...copy.form, skills: ["R"] } }), now)?.form.skills, ["R"]);
  for (const value of ["{", JSON.stringify({ ...copy, id: "invalid" }), JSON.stringify({ ...copy, savedAt: now - 86400001 })]) assert.equal(readDraftRecovery(value, now), null);
});
test("знаки препинания и одно добавленное слово не маскируют копию поля", () => {
  const text = "Менеджеры теряют заявки клиентов в разных таблицах и забывают вовремя отвечать на обращения.";
  const result = evaluateTaskQuality({ problem: text, goal: text.replace(".", "!") + " Сегодня." });
  assert.ok(result.criteria.filter(item => ["problem", "goal"].includes(item.key)).every(item => item.earned < item.points));
  assert.equal(evaluateTaskQuality({ skills: ["а", "тест", "аааааа"] }).score, 0);
});
test("схема OpenAI ограничивает длину полей и количество вопросов", async () => {
  const draft = taskPayloadSchema.parse({});
  await suggestBrief("test", "gpt-4.1-mini", "Описание задачи для тестирования", draft, async (_url, init) => {
    const schema = JSON.parse(String(init?.body)).text.format.schema;
    assert.equal(schema.properties.task.properties.title.maxLength, 140);
    assert.equal(schema.properties.task.properties.skills.maxItems, 10);
    assert.equal(schema.properties.questions.maxItems, 6);
    assert.ok(schema.required.includes("evidence"));
    return Response.json({ output: [{ content: [{ type: "output_text", text: JSON.stringify({ task: draft, evidence: [], questions: [], note: "Уточните задачу" }) }] }] });
  });
});
