import { z } from "zod";
import { taskPayloadSchema } from "./task-payload.ts";

export const recoverySchema = z.object({
  version: z.literal(1),
  id: z.string().uuid(),
  // An unfinished skill (e.g. "R") must not invalidate the other recovered fields.
  form: taskPayloadSchema.extend({ skills: z.array(z.string().max(510)).max(256) }),
  description: z.string().max(6000),
  sourceDescription: z.string().max(6000).optional(),
  savedAt: z.number().finite(),
  baseUpdatedAt: z.number().nullable(),
});
export type DraftRecovery = z.infer<typeof recoverySchema>;
export function readDraftRecovery(value: string | null, now = Date.now()): DraftRecovery | null {
  if (!value) return null;
  try {
    const result = recoverySchema.safeParse(JSON.parse(value));
    if (!result.success || result.data.savedAt > now + 60000 || now - result.data.savedAt > 24 * 60 * 60 * 1000) return null;
    return result.data;
  } catch { return null; }
}
